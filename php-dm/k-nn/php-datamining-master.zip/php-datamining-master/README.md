# intelligent-system
- Read dataset csv
- berisi algoritme-algoritme dalam data mining/machine learning

# Requirment
- install xampp (atau web server lokal lainnya)
- install text editor (notepad++, geany, dll)
- download bootstrap (untuk mempercantik tampilan web), melalui link: https://getbootstrap.com/

# Cara pemakaian
1. Buat folder baru di dalam folder htdocs (contoh: folder "belajar-dm")
2. Clone atau Download repository ini
3. Simpan di dalam folder belajar-dm (.../xampp/htdocs/belajar-dm/...)
