<?php

declare(strict_types=1);

namespace jokodm\Datamining\Exception;

use Exception;

class InvalidOperationException extends Exception
{
}
