<?php

declare(strict_types=1);

namespace jokodm\Datamining\Klasifikasi;

use jokodm\Datamining\Estimator;

interface Classifier extends Estimator
{
}
